module.exports = {
    root: true,
    extends: "eslint:recommended"
};